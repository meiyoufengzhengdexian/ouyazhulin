@extends('layout.admin')

@section('right_col')
    <div class="right_col">

    </div>
@endsection