<?php $__env->startSection('right_col'); ?>
    <div class="right_col">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>分类列表</h3>
                </div>
                <div class="title_right">
                    <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search for...">
                            <span class="input-group-btn">
                              <button class="btn btn-default" type="button">Go!</button>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-warning" id="test" style="color: #FFF;">
                            <a href="#" class="close" data-dismiss="alert">
                                &times;
                            </a>
                            <strong>警告！</strong><?php echo e($error); ?>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="x_content">
                            <div id="table" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                <div class="col-sm-12">
                                    <table id="datatable" class="table table-striped table-bordered dataTable no-footer" style="vertical-align: middle; margin-bottom: 0;">
                                        <thead>
                                        <tr>
                                            <th width="35px">id</th>
                                            <th>排序</th>
                                            <th>分类名称</th>
                                            <th>图片</th>
                                            <th width="75px">操作</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($k->id); ?></td>
                                            <td><?php echo e($k->order); ?></td>
                                            <td><?php echo e($k->name); ?></td>
                                            <td><div style="max-height: 100px;max-width: 100px;"><img src="<?php echo e(asset(is_null($k->img) ? 'public/images/default.png':('storage/app/'.$k->img ))); ?>" alt="" class="img-responsive" style="max-height: 50px;"></div></td>
                                            <td>
                                                <a href="<?php echo e(url('admin/category/'.$k->id.'/edit')); ?>" class="btn btn-info btn-xs">编辑</a>
                                                <a href="<?php echo e(url('admin/category', ['id'=>$k->id])); ?>" class="btn btn-danger btn-xs del">删除</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('addcss'); ?>
<!-- Datatables -->
<link href="<?php echo e(asset('public/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css')); ?>" rel="stylesheet">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('addjs'); ?>
<script src="<?php echo e(asset('public/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendors/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendors/datatables.net-buttons/js/buttons.flash.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendors/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendors/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendors/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendors/datatables.net-scroller/js/dataTables.scroller.min.js')); ?>"></script>
<script>
    $(function(){
        $('#datatable').DataTable();
        $('body').on('click', '.del', function(e){
            e.preventDefault();
            var url = $(this).attr('href');
            var _this = this;
            $.ajax({
                url:url,
                type:'DELETE',
                success:function(res){
                    var status = res.status | 0;
                    if(status){
                        $(_this).parents('tr').fadeOut(300, function(){
                            $(this).remove();
                        });
                    }
                },
                error:function(res){
                    console.log(res);
                }
            });
        });
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            new PNotify({
            title: 'Oh No!',
            text: '<?php echo e($e); ?>',
            type: 'error'
        });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    });


</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>