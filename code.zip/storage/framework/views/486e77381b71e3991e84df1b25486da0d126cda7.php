__template__

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class <?php echo e($model); ?> extends Model
{
    protected $table = '<?php echo e(strtolower($model)); ?>';
    protected $guarded = [];
    protected $dates = ['deleted_at'];

    use SoftDeletes;

    <?php $__currentLoopData = $col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($v['type'] == 'select' && $v['from_table'] && $v['f_name']): ?>
    public function <?php echo e(strtolower($v['from_table'].'_'.$v['f_name'])); ?>()
    {
        return $this->belongsTo('App\Model\<?php echo e(ucfirst($v['from_table'])); ?>', '<?php echo e($v['col']); ?>', 'id');
    }
            <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

}
