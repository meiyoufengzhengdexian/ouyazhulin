__template__

namespace App\Http\Controllers\Admin;

use App\Model\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class <?php echo e($controller); ?>Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return  \Illuminate\Http\Response
     */
    protected $validateRoule = [
        <?php $__currentLoopData = $col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if( in_array($v['col'], $time) ): ?>
                <?php continue; ?>
                <?php endif; ?>
            <?php 
            switch($v['type']){
                case 'text':
                    echo "'{$v['col']}'=> 'required|max:100',\n";
                    break;
                case 'image':
                    echo "'{$v['col']}'=> 'required',\n";
                    break;
                case 'select':
                    if($v['from_table'] && $v['f_name']){
                        echo "'{$v['col']}'=> 'required|exists:{$v['from_table']},id'";
                    }
                    break;
            }
             ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ];
    public function index()
    {
        $list = \App\Model\<?php echo e($controller); ?>::paginate(100);
        return view('admin.<?php echo e(strtolower($controller)); ?>.index', compact('list'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return  \Illuminate\Http\Response
     */
    public function create()
    {
        <?php 
            $form = [];
         ?>
        <?php $__currentLoopData = $col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($v['type'] == 'select' && $v['from_table'] && $v['f_name']): ?>
                $<?php echo e($v['from_table'].'_'.$v['f_name']); ?>s = <?php echo e(ucfirst($v['from_table'])); ?>::all();
                <?php 
                    $form[] = $v['from_table'].'_'.$v['f_name']."s";
                 ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php 
            $str = implode("','", $form);
            $compact = $str ? ", compact('".$str."')": '';
         ?>
        return view('admin.<?php echo e(strtolower($controller)); ?>.create' <?php echo $compact; ?>);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param    \Illuminate\Http\Request  $request
     * @return  \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $data = $request->all();
        $this->validate($request, $this->validateRoule);
        unset($data['uploadImg']);

        \App\Model\<?php echo e($controller); ?>::create($data);
        return redirect('<?php echo e(strtolower('admin/'.$controller)); ?>');
    }

    /**
     * Display the specified resource.
     *
     * @param    int  $id
     * @return  \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param    int  $id
     * @return  \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = \App\Model\<?php echo e($controller); ?>::findOrFail($id);
        <?php 
            $form = ['data'];
         ?>
        <?php $__currentLoopData = $col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($v['type'] == 'select' && $v['from_table'] && $v['f_name']): ?>
                $<?php echo e($v['f_name']); ?>s = <?php echo e(ucfirst($v['from_table'])); ?>::all();
                <?php 
                    $form[] = $v['f_name']."s";
                 ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php 
            $str = implode("','", $form);
            $compact = $str ? ", compact('".$str."')": '';
         ?>
        return view('admin.<?php echo e(strtolower('admin/'.$controller)); ?>.edit'<?php echo $compact; ?>);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param    \Illuminate\Http\Request  $request
     * @param    int  $id
     * @return  \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $this->validate($request, $this->validateRoule);
        $data = $request->all();

        unset($data['uploadImg']);
        \App\Model\<?php echo e($controller); ?>::findOrFail($id)->update($data);
        return redirect('<?php echo e(strtolower('admin/'.$controller)); ?>');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param    int  $id
     * @return  \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $cate = \App\Model\<?php echo e($controller); ?>::findOrFail($id);
        $cate->delete();
        return response()->json([
            'status'=>true
        ]);
    }
}
