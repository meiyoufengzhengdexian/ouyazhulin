<?php $__env->startSection('right_col'); ?>
    <div class="right_col">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Code</h3>
                </div>
                <div class="title_right">
                    <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                        <div class="input-group">
                            <button class="btn btn-danger" type="submit" form="form">生成</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_content">
                            <div id="table" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                <div class="col-sm-12">
                                    <form action="<?php echo e(url('code')); ?>" method="post" id="form">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('put')); ?>

                                        <input type="hidden" name="table" value="<?php echo e($table); ?>">
                                    <table id="datatable" class="table table-striped table-bordered dataTable no-footer" style="vertical-align: middle; margin-bottom: 0;">
                                        <thead>
                                        <tr>
                                            <th width="35px">col</th>
                                            <th>alias</th>
                                            <th>字段类型</th>
                                            <th>列表页</th>
                                            <th>添加页</th>
                                            <th>编辑页</th>
                                            <th>默认值</th>
                                            <th>来自哪张表</th>
                                            <th>option名</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" name="field[<?php echo e($v['col']); ?>][col]" value="<?php echo e($v['col']); ?>">
                                            <tr>
                                                <td><?php echo e($v['col']); ?></td>
                                                <td><input type="text" name="field[<?php echo e($v['col']); ?>][alias]" value="<?php echo e($v['alias']); ?>"></td>
                                                <td>
                                                    <select name="field[<?php echo e($v['col']); ?>][type]" id="type" class="form-control">
                                                        <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($t); ?>"
                                                                    <?php if($t == $v['type']): ?>
                                                                    selected="true"
                                                                    <?php endif; ?>
                                                            ><?php echo e($t); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="checkbox" class="js-switch" data-switchery="true"
                                                           <?php if($v['index']): ?>
                                                           checked
                                                           <?php endif; ?>
                                                           name="field[<?php echo e($v['col']); ?>][index]" value="1" id="index">
                                                </td>
                                                <td>
                                                    <input type="checkbox" class="js-switch" data-switchery="true"
                                                           <?php if($v['add']): ?>
                                                           checked
                                                           <?php endif; ?>
                                                           name="field[<?php echo e($v['col']); ?>][add]" value="1" id="add">
                                                </td>
                                                <td>
                                                    <input type="checkbox" class="js-switch" data-switchery="true"
                                                           <?php if($v['edit']): ?>
                                                           checked
                                                           <?php endif; ?>
                                                           name="field[<?php echo e($v['col']); ?>][edit]" value="1" id="edit">
                                                </td>
                                                <td><input type="text" name="field[<?php echo e($v['col']); ?>][default]" value="<?php echo e($v['default']); ?>"></td>
                                                <td><input type="text" name="field[<?php echo e($v['col']); ?>][from_table]" value="<?php echo e($v['from_table']); ?>"></td>
                                                <td><input type="text" name="field[<?php echo e($v['col']); ?>][f_name]" value="<?php echo e($v['f_name']); ?>"></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('addcss'); ?>
<!-- Datatables -->
<link href="<?php echo e(asset('public/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/vendors/switchery/dist/switchery.min.css')); ?>" rel="stylesheet">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('addjs'); ?>
<script src="<?php echo e(asset('public/vendors/switchery/dist/switchery.min.js')); ?>"></script>
<script>
    $(function(){
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            new PNotify({
            title: 'Oh No!',
            text: '<?php echo e($e); ?>',
            type: 'error'
        });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    });


</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>