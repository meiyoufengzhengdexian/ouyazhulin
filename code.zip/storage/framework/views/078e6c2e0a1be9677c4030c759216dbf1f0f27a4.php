<?php $__env->startSection('right_col'); ?>
    <div class="right_col">
        <div class="page-title">
            <div class="title_left">
                <h2>编辑Chexing</h2>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <form class="form-horizontal form-label-left" novalidate data-parsley-validate
                              action="<?php echo e(url("admin/chexing/$data->id")); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PATCH')); ?>

                        <span class="section">Chexing信息</span>
                                                                                                                                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                       for="chexing">车辆类型</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="chexing" class="form-control col-md-7 col-xs-12" name="chexing" placeholder="请输入车辆类型" required="required" value="<?php echo e($data->chexing); ?>" type="text">
                                </div>
                            </div>
                                                                                <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12"
                                       for="pinpai_id">品牌</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select name="pinpai_id" id="pinpai_id" class="form-control">
                                            <?php $__currentLoopData = $pinpai_pinpais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pinpai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                 <?php if($pinpai->id == $data->pinpai_id): ?>
                                                    selected="true"
                                                <?php endif; ?>
                                                 value="<?php echo e($pinpai->id); ?>"><?php echo e($pinpai->pinpai); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                </div>
                            </div>
                                                                                                                                                                                                            

                        <div class="ln_solid"></div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-3">
                                <button type="reset" class="btn btn-primary">取消</button>
                                <button id="send" type="submit" class="btn btn-success">确定</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php $__env->startPush('addcss'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('addjs'); ?>
<script src="<?php echo e(asset('public/vendors/validator/validator.js')); ?>"></script>
<script>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        new PNotify({
        title: 'Oh No!',
        text: '<?php echo e($e); ?>',
        type: 'error'
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>