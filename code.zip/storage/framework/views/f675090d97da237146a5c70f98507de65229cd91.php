<?php $__env->startSection('right_col'); ?>
    <div class="right_col">
        <div class="page-title">
            <div class="title_left">
                <h2>编辑分类</h2>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <form class="form-horizontal form-label-left" novalidate data-parsley-validate action="<?php echo e(url("category/{$data->id}")); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>

                            <span class="section">分类信息</span>

                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">分类名称 <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="name" class="form-control col-md-7 col-xs-12" name="name" value="<?php echo e($data->name); ?>" placeholder="请输入一个分类名称" required="required" type="text">
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="fid">上级分类 <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select name="fid" id="fid" class="form-control">
                                        <?php $__currentLoopData = $fids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($k->id); ?>"
                                                <?php if($k->id == $data->fid): ?>
                                                    selected="true"
                                                <?php endif; ?>
                                            ><?php echo e($k->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="is_show">是否在导航栏显示
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="checkbox" class="js-switch" data-switchery="true"
                                           <?php if($data->is_show): ?>
                                               checked
                                           <?php endif; ?>
                                           name="is_show" value="1" id="is_show">
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="order">排序
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input  type="number" name="order" id="order" class="form-control col-md-7 col-xs-12" value="<?php echo e($data->order); ?>" data-validate-minmax="0," required="required">
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="desc">描述
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <textarea id="desc" name="desc" class="form-control col-md-7 col-xs-12"><?php echo e($data->desc); ?></textarea>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="img">标题图片
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="file" name="uploadImg" class="uploadImg" data-realname="img">
                                    <input type="hidden" name="img" value="<?php echo e($data->img); ?>">
                                </div>
                            </div>

                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-3">
                                    <button type="reset" class="btn btn-primary">取消</button>
                                    <button id="send" type="submit" class="btn btn-success">确定</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addcss'); ?>
<link href="<?php echo e(asset('public/vendors/switchery/dist/switchery.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('addjs'); ?>

<script src="<?php echo e(asset('public/vendors/validator/validator.js')); ?>"></script>
<script src="<?php echo e(asset('public/vendors/switchery/dist/switchery.min.js')); ?>"></script>
<script>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                new PNotify({
        title: 'Oh No!',
        text: '<?php echo e($e); ?>',
        type: 'error'
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        $(function(){
        $('.uploadImg').fileinput({
            showCaption: false,
            showRemove:true,
            showCancel:true,
            uploadAsync:true,
            uploadUrl: "/upload",
            initialPreview:[
                $('input[name='+$('.uploadImg').data('realname')+']').val() != ''
                ? '<img style="max-height: 100%; max-width: 100%;display: block;" src="/storage/app/'+ $('input[name='+$('.uploadImg').data('realname')+']').val() +'" alt="">'
                :''
            ]

        }).on('filebatchselected', function(event, files){
            $(this).fileinput('upload');
        }).on('fileuploaded', function(event, data, previewId, index){
            var name = $(this).data('realname');
            $('input[name='+name+']').val(data.response.path);
        }).on('filesuccessremove fileclear filepreremove fileremoved filepredelete filedeleted ', function(event, id){
            var name = $(this).data('realname');
            var path = $('input[name='+name+']').val();
            var img = $('input[name='+$(this).data('realname')+']');
            $.ajax({
                url:'/upload',
                data:{
                    path:path
                },
                method:"DELETE",
                success:function(){
                    img.val("");
                }
            });
        })
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>